# File chứa các hàm helper chung


def example_helper_function():
    return "This is a helper function"
